/*
 * Tests if this still compiles when multiple .proto files are involved.
 */

#include <stdio.h>
#include <pb_encode.h>
#include "callbacks2.pb.h"

int main()
{
	return 0;
}
